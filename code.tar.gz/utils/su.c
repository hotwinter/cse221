#include <stdlib.h>
#include "util.h"

int main(int argc, char **argv) {
    get_root();
    system("/system/bin/sh");
    return 0;
}
